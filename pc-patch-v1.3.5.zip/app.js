'use strict';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

const WRONG_KEY = 'xc_wrong_v2';
const WRONG_OLD = 'xc_wrong_v1';
const FAV_KEY = 'xc_fav_v1';
const STATS_KEY = 'xc_stats_v1';
const DAILY_KEY = 'xc_daily_v1';
const CHECKIN_KEY = 'xc_checkin_v1';
const SETTINGS_KEY = 'xc_settings_v1';
const PAPERS = 515;

// 各模块建议单题用时（秒）
const SUGGEST = { '01': 25, '02': 25, '03': 45, '04': 60, '05': 45, '06': 70 };

// 模拟考试套卷预设（按真实题量结构分配各模块题数）
const EXAM_PRESETS = [
  { id: 'gk_di', name: '国考·地市级', minutes: 120, alloc: { '01': 10, '02': 15, '03': 40, '04': 10, '05': 40, '06': 15 } },
  { id: 'gk_fu', name: '国考·副省级', minutes: 120, alloc: { '01': 10, '02': 15, '03': 40, '04': 15, '05': 40, '06': 15 } },
  { id: 'shengkao', name: '省考联考', minutes: 120, alloc: { '01': 10, '02': 15, '03': 35, '04': 10, '05': 35, '06': 15 } },
  { id: 'sz', name: '深圳市考', minutes: 90, alloc: { '01': 10, '02': 15, '03': 25, '04': 10, '05': 30, '06': 10 } },
];

const state = {
  manifest: null,
  moduleCache: {},
  session: null,
  wrong: {},
  fav: {},
  stats: [],
  dailyMap: {},
  checkin: {},
  settings: {},
  timerId: null,
  selectedPreset: EXAM_PRESETS[0].id,
};

// ---------- 工具 ----------
function pad(n) { return (n < 10 ? '0' : '') + n; }
function fmtTime(sec) { sec = Math.max(0, Math.floor(sec)); return pad(Math.floor(sec / 60)) + ':' + pad(sec % 60); }
function fmtDate(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
function todayStr() { return fmtDate(new Date()); }
function stripTags(s) { return String(s || '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim(); }
function truncate(s, n = 90) { const t = stripTags(s); return t.length > n ? t.slice(0, n) + '…' : t; }
function escapeHtml(s) { return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

function toast(msg) {
  const t = $('#toast');
  t.textContent = msg; t.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => (t.hidden = true), 1800);
}

// ---------- 存储 ----------
function loadStore(key, def) { try { return JSON.parse(localStorage.getItem(key) || 'null') || def; } catch { return def; } }
function saveStore(key, val) { try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) {} }

function loadWrong() {
  state.wrong = loadStore(WRONG_KEY, null);
  if (!state.wrong) { const old = loadStore(WRONG_OLD, null); state.wrong = old || {}; if (old) saveStore(WRONG_KEY, state.wrong); }
  updateBadges();
}
function saveWrong() { saveStore(WRONG_KEY, state.wrong); updateBadges(); }
function loadFav() { state.fav = loadStore(FAV_KEY, {}); updateBadges(); }
function saveFav() { saveStore(FAV_KEY, state.fav); updateBadges(); }
function loadStats() { state.stats = loadStore(STATS_KEY, []); }
function saveStats() { saveStore(STATS_KEY, state.stats); }
function loadDailyMap() { state.dailyMap = loadStore(DAILY_KEY, {}); if (!state.dailyMap[todayStr()]) state.dailyMap[todayStr()] = { secs: 0, questions: 0 }; }
function saveDailyMap() { saveStore(DAILY_KEY, state.dailyMap); }
function loadCheckin() { state.checkin = loadStore(CHECKIN_KEY, {}); }
function saveCheckin() { saveStore(CHECKIN_KEY, state.checkin); }
function loadSettings() { state.settings = loadStore(SETTINGS_KEY, {}); }
function saveSettings() { saveStore(SETTINGS_KEY, state.settings); }

function updateBadges() {
  const w = Object.values(state.wrong).filter((x) => !x.mastered).length;
  const wb = $('#wrongBadge'); if (wb) { wb.textContent = w; wb.hidden = w === 0; }
  const f = Object.keys(state.fav).length;
  const fb = $('#favBadge'); if (fb) { fb.textContent = f; fb.hidden = f === 0; }
}

function markCheckin(date) { state.checkin[date] = true; saveCheckin(); }

function computeStreak() {
  const c = state.checkin; let streak = 0;
  const d = new Date();
  if (!c[todayStr()]) d.setDate(d.getDate() - 1);
  while (c[fmtDate(d)]) { streak++; d.setDate(d.getDate() - 1); }
  return streak;
}

function addRecord(r) {
  r.ts = Date.now(); r.date = todayStr();
  state.stats.push(r);
  if (state.stats.length > 2000) state.stats = state.stats.slice(-2000);
  saveStats();
}

function moduleKeyByName(name) { const m = state.manifest && state.manifest.modules.find((x) => x.name === name); return m ? m.key : null; }

async function getModule(key) {
  if (state.moduleCache[key]) return state.moduleCache[key];
  const res = await fetch(`data/${key}.json`);
  if (!res.ok) throw new Error('模块数据加载失败: ' + key);
  const arr = await res.json();
  state.moduleCache[key] = arr;
  return arr;
}

// ---------- 地区分类 ----------
const PROVINCE_SET = new Set([
  '北京', '天津', '上海', '重庆',
  '河北', '山西', '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建', '江西',
  '山东', '河南', '湖北', '湖南', '广东', '海南', '四川', '贵州', '云南', '陕西',
  '甘肃', '青海', '台湾',
  '内蒙古', '广西', '西藏', '宁夏', '新疆',
  '香港', '澳门',
]);
const SPECIAL_EXAMS = ['国考', '选调', '深圳市考', '广州市考'];
function classifyRegion(r) {
  if (SPECIAL_EXAMS.includes(r)) return '专项考试';
  if (PROVINCE_SET.has(r)) return '省份';
  return '其他';
}
function fillRegionSelect(el, regionCounts) {
  const cur = el.value;
  el.innerHTML = '<option value="">全部</option>';
  const values = Object.keys(regionCounts || {});
  const groups = {};
  values.forEach((v) => { const g = classifyRegion(v); (groups[g] = groups[g] || []).push(v); });
  ['省份', '专项考试', '其他'].forEach((g) => {
    if (!groups[g] || !groups[g].length) return;
    const og = document.createElement('optgroup'); og.label = g;
    groups[g].sort((a, b) => a.localeCompare(b, 'zh-Hans-CN')).forEach((v) => {
      const o = document.createElement('option'); o.value = v; o.textContent = `${v}（${regionCounts[v]}）`; og.appendChild(o);
    });
    el.appendChild(og);
  });
  if (values.includes(cur)) el.value = cur;
}

// ---------- 视图切换 ----------
function switchView(name) {
  if (name !== 'session' && state.session && !state.session.ended) stopTimer();
  if (name !== 'session') $$('.navbtn').forEach((b) => b.classList.toggle('active', b.dataset.view === name));
  $$('.view').forEach((v) => v.classList.remove('active'));
  const el = $('#view-' + name); if (el) el.classList.add('active');
  if (name === 'home') renderHome();
  if (name === 'wrong') renderWrongList();
  if (name === 'fav') renderFavList();
  if (name === 'stats') renderStats();
  if (name === 'overview') renderOverview();
  if (name === 'about') renderAbout();
  if (name === 'exam') renderExamPresets();
  if (name === 'license') loadLicenseInfo();
  if (name === 'practice') updateFreeLimitHints();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ---------- 初始化筛选 ----------
function initFilters() {
  const modSel = $('#f-module'); modSel.innerHTML = '';
  state.manifest.modules.forEach((m) => {
    const o = document.createElement('option'); o.value = m.key; o.textContent = `${m.name}（${m.count}）`; modSel.appendChild(o);
  });
  [['#wf-module'], ['#ff-module']].forEach(([sel]) => {
    const e = $(sel); e.innerHTML = '<option value="">全部模块</option>';
    state.manifest.modules.forEach((m) => { const o = document.createElement('option'); o.value = m.name; o.textContent = m.name; e.appendChild(o); });
  });
  modSel.addEventListener('change', onModuleChange);
  onModuleChange();
}
function onModuleChange() {
  const m = state.manifest.modules.find((x) => x.key === $('#f-module').value);
  fillSelect('#f-year', m.years);
  fillSelect('#f-type', m.types);
  fillRegionSelect($('#f-region'), m.regionCounts || {});
}
function fillSelect(sel, values) {
  const el = $(sel); const cur = el.value;
  el.innerHTML = '<option value="">全部</option>';
  values.forEach((v) => { const o = document.createElement('option'); o.value = v; o.textContent = v; el.appendChild(o); });
  if (values.includes(cur)) el.value = cur;
}

// ---------- 开始练习 / 考试 ----------
async function startPractice(questionsOverride, opts = {}) {
  let questions;
  if (questionsOverride) {
    questions = questionsOverride.filter((q) => !q.incomplete);
  } else {
    const key = $('#f-module').value;
    const year = $('#f-year').value;
    const type = $('#f-type').value;
    const region = $('#f-region').value;
    const search = ($('#f-search').value || '').trim().toLowerCase();
    let count = parseInt($('#f-count').value, 10) || 20;
    const shuffle = $('#f-shuffle').checked;
    const examMode = $('#f-pmode-exam').checked;
    const tlimit = parseInt($('#f-tlimit').value, 10) || 60;

    toast('加载题库…');
    let all;
    try { all = await getModule(key); } catch (e) { toast(e.message); return; }

    let pool = all.filter((q) =>
      !q.incomplete &&
      (!year || q.year === year) &&
      (!type || q.type === type) &&
      (!region || q.region === region) &&
      (!search || stripTags(q.stem).toLowerCase().includes(search))
    );
    if (!pool.length) { toast('该条件下没有题目'); return; }
    if (shuffle) {
      pool = pool.slice();
      for (let i = pool.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [pool[i], pool[j]] = [pool[j], pool[i]]; }
    }
    questions = pool.slice(0, Math.min(count, pool.length));
    if (questions.length < count) toast(`仅 ${questions.length} 题，已为您全部选取`);

    // 免费版限制：练习题量总量上限（终身累计，不按天重置）
    if (!isActivated() && FREE_LIMIT.questionLimit > 0) {
      const used = getQuestionCountTotal();
      const remain = Math.max(0, FREE_LIMIT.questionLimit - used);
      if (remain === 0) {
        showLimitModal('免费练习额度已用完',
          limitNotice('的练习额度（共 ' + FREE_LIMIT.questionLimit + ' 题）'));
        return;
      }
      if (questions.length > remain) {
        questions = questions.slice(0, remain);
        toast('免费版还可练 ' + remain + ' 题（共 ' + FREE_LIMIT.questionLimit + ' 题），已自动截取');
      }
      incQuestionCountTotal(questions.length);
    }

    state.session = buildSession(questions, {
      kind: examMode ? 'exam' : 'practice', examPreset: null, review: false, timeLimit: examMode ? tlimit * 60 : 0,
      moduleLabel: state.manifest.modules.find((x) => x.key === key).name,
    });
    beginSession();
    return;
  }

  if (!questions.length) { toast('没有可练的题目'); return; }
  state.session = buildSession(questions, {
    kind: 'practice', examPreset: null, review: true, timeLimit: 0,
    smart: opts.smart, favReview: opts.favReview,
    moduleLabel: opts.favReview ? '收藏复习' : (opts.smart ? '智能复习' : '错题复习'),
  });
  beginSession();
}

function buildSession(questions, opt) {
  return {
    questions, index: 0, sel: {}, submitted: {}, results: {}, qTime: {}, qStart: {},
    kind: opt.kind, examPreset: opt.examPreset, review: opt.review, smart: !!opt.smart, favReview: !!opt.favReview,
    moduleLabel: opt.moduleLabel, timeLimit: opt.timeLimit || 0, timeLeft: opt.timeLimit || 0,
    elapsed: 0, ended: false, noRecord: !!opt.noRecord,
  };
}

async function startExam(presetId) {
  const preset = EXAM_PRESETS.find((p) => p.id === presetId) || EXAM_PRESETS[0];
  // 免费版限制：模拟考试总套数（终身累计，不按天重置）
  const limitMsg = checkFreeLimit('exam');
  if (limitMsg) {
    showLimitModal('免费模拟考试额度已用完',
      limitNotice('的模拟考试额度（共 ' + FREE_LIMIT.examLimit + ' 套）'));
    return;
  }
  toast('组卷中…');
  let questions = [];
  try {
    for (const key of Object.keys(preset.alloc)) {
      const arr = await getModule(key);
      let part = arr.filter((q) => !q.incomplete).slice();
      for (let i = part.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [part[i], part[j]] = [part[j], part[i]]; }
      questions = questions.concat(part.slice(0, preset.alloc[key]));
    }
    for (let i = questions.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [questions[i], questions[j]] = [questions[j], questions[i]]; }
  } catch (e) { toast(e.message); return; }
  if (!questions.length) { toast('组卷失败'); return; }
  incExamCountTotal();   // 记录累计已用考试次数（免费版限流用）
  state.session = buildSession(questions, { kind: 'exam', examPreset: preset, review: false, timeLimit: preset.minutes * 60, moduleLabel: '全卷·' + preset.name });
  beginSession();
}

function beginSession() {
  const s = state.session;
  markCheckin(todayStr());
  switchView('session');
  $('#session').hidden = false;
  $('#session-report').hidden = true;
  $('#practice-side').hidden = false;
  buildSessionSummary();
  const isExam = s.kind === 'exam';
  $('#side-time-label').textContent = isExam ? '剩余时间' : '本次用时';
  $('#side-time').classList.toggle('countdown', isExam);
  $('#side-acc-card').hidden = isExam;
  $('#btn-end-session').textContent = isExam ? '交卷' : '结束练习';
  renderQuestion();
  startTimer();
}

function buildSessionSummary() {
  const s = state.session; let txt;
  if (s.review) txt = (s.moduleLabel || '复习') + ' · ' + s.questions.length + ' 题';
  else if (s.kind === 'exam') txt = '模拟考试 · ' + (s.examPreset ? s.examPreset.name : '自定义') + ' · ' + s.questions.length + ' 题 / ' + Math.round(s.timeLimit / 60) + ' 分';
  else txt = s.moduleLabel + ' · 自定义练习 · ' + s.questions.length + ' 题';
  $('#session-summary-text').textContent = txt;
}

// ---------- 计时 ----------
function startTimer() {
  stopTimer();
  updateSideTime();
  state.timerId = setInterval(() => {
    const s = state.session;
    if (!s || s.ended) { stopTimer(); return; }
    s.elapsed++;
    if (s.kind === 'exam') {
      s.timeLeft--;
      if (s.timeLeft <= 0) { s.timeLeft = 0; updateSideTime(); timeUp(); return; }
    } else {
      const d = state.dailyMap[todayStr()]; if (d) d.secs++;
      saveDailyMapThrottled();
    }
    updateSideTime();
  }, 1000);
}
function stopTimer() { if (state.timerId) { clearInterval(state.timerId); state.timerId = null; } }
function timeUp() {
  const s = state.session; if (!s) return;
  s.questions.forEach((q, i) => { if (!s.submitted[i]) { s.submitted[i] = true; s.results[i] = false; } });
  toast('时间到，自动交卷');
  endSession();
}
function updateSideTime() {
  const s = state.session; if (!s) return;
  $('#side-time').textContent = s.kind === 'exam' ? fmtTime(s.timeLeft) : fmtTime(s.elapsed);
  if (s.kind === 'exam') $('#side-time-total').textContent = '已用 ' + fmtTime(s.elapsed);
  else { const d = state.dailyMap[todayStr()]; $('#side-time-total').textContent = '今日累计 ' + fmtTime(d ? d.secs : 0); }
}
let _saveD = 0;
function saveDailyMapThrottled() { const now = Date.now(); if (now - _saveD > 4000) { _saveD = now; saveDailyMap(); } }

// ---------- 渲染题目 ----------
function renderQuestion() {
  const s = state.session; if (!s) return;
  const q = s.questions[s.index];
  if (!s.submitted[s.index] && s.qStart[s.index] === undefined) s.qStart[s.index] = Date.now();
  updateSidePanel();
  renderAnswerSheet();

  $('#q-type').textContent = q.type || '—';
  $('#q-src').textContent = [q.paper, q.year, q.region].filter(Boolean).join(' · ');

  const mat = $('#q-material');
  if (q.material && q.material.trim()) { mat.hidden = false; mat.innerHTML = q.material; } else mat.hidden = true;
  $('#q-stem').innerHTML = q.stem || '';

  const opts = $('#q-options'); opts.innerHTML = '';
  const selected = s.sel[s.index] || [];
  const submitted = s.submitted[s.index];
  const showResult = submitted && (s.kind === 'practice' || s.ended);
  q.options.forEach((o) => {
    const div = document.createElement('div');
    div.className = 'opt' + (submitted ? ' locked' : '');
    const isSel = selected.includes(o.key);
    if (showResult) { if (o.correct) div.classList.add('correct'); else if (isSel) div.classList.add('wrong'); else div.classList.add('dim'); }
    else if (isSel) div.classList.add('selected');
    div.innerHTML = `<div class="key">${o.key}</div><div class="body">${o.html}</div>`;
    if (!submitted) div.addEventListener('click', () => toggleOption(o.key));
    opts.appendChild(div);
  });

  const res = $('#q-result');
  if (showResult) { res.hidden = false; renderResult(q, selected); } else res.hidden = true;
  const bs = $('#btn-submit'); bs.disabled = submitted; bs.textContent = submitted ? (s.kind === 'exam' ? '已作答' : '已提交') : '提交答案';
  $('#btn-prev').disabled = s.index === 0;
  $('#btn-next').disabled = s.index === s.questions.length - 1;
}

function renderAnswerSheet() {
  const s = state.session; const grid = $('#answer-sheet'); if (!grid || !s) return;
  grid.innerHTML = '';
  const showResult = s.kind === 'practice' || s.ended;
  s.questions.forEach((q, i) => {
    const c = document.createElement('div'); let cls = 'sheet-cell';
    const sub = s.submitted[i]; const isRight = s.results[i] === true;
    if (showResult && sub) cls += ' ' + (isRight ? 'right' : 'wrong');
    else if (sub) cls += ' answered';
    if (i === s.index && !s.ended) cls += ' current';
    c.className = cls; c.textContent = i + 1; c.title = '第 ' + (i + 1) + ' 题';
    if (!s.ended) c.addEventListener('click', () => { s.index = i; renderQuestion(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
    grid.appendChild(c);
  });
  const lg = $('#sheet-legend');
  if (showResult) lg.innerHTML = legendHTML([['对', 'var(--ok)'], ['错', 'var(--bad)'], ['未答', 'var(--line)']]);
  else if (s.kind === 'exam') lg.innerHTML = legendHTML([['已答', 'var(--accent)'], ['未答', 'var(--line)'], ['当前', 'var(--accent)']]);
  else lg.innerHTML = legendHTML([['已答', 'var(--accent)'], ['对', 'var(--ok)'], ['错', 'var(--bad)'], ['当前', 'var(--accent)']]);
}
function legendHTML(arr) { return arr.map(([t, c]) => `<span><i style="background:${c}"></i>${t}</span>`).join(''); }

function toggleOption(key) {
  const s = state.session; const q = s.questions[s.index];
  let sel = s.sel[s.index] ? s.sel[s.index].slice() : [];
  if (q.multiSelect) { if (sel.includes(key)) sel = sel.filter((k) => k !== key); else sel.push(key); } else sel = [key];
  s.sel[s.index] = sel; renderQuestion();
}

function submitAnswer() {
  const s = state.session; if (!s || s.submitted[s.index]) return;
  const q = s.questions[s.index]; const sel = s.sel[s.index] || [];
  if (!sel.length) { toast('请先选择答案'); return; }
  const isRight = q.correct.slice().sort().join('') === sel.slice().sort().join('');
  s.submitted[s.index] = true; s.results[s.index] = isRight;
  if (s.qStart[s.index] !== undefined) s.qTime[s.index] = Math.max(0, (Date.now() - s.qStart[s.index]) / 1000);
  if (s.kind === 'practice') syncWrong(q, isRight);
  renderQuestion();
  if (s.kind === 'practice') $('#q-result').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  else toast('已记录本题');
}
function syncWrong(q, isRight) {
  if (isRight) { if (state.wrong[q.qid]) { delete state.wrong[q.qid]; saveWrong(); } }
  else { addWrong(q); saveWrong(); }
}

function renderResult(q, sel) {
  const res = $('#q-result');
  const isRight = q.correct.slice().sort().join('') === sel.slice().sort().join('');
  const verdict = document.createElement('div');
  verdict.className = 'verdict ' + (isRight ? 'ok' : 'bad');
  verdict.textContent = isRight ? '回答正确' : '回答错误';

  const ans = document.createElement('div'); ans.className = 'answer-line';
  let paceHtml = '';
  const t = state.session.qTime[state.session.index];
  if (t !== undefined) {
    const modObj = state.manifest.modules.find((x) => x.name === q.module);
    const sug = SUGGEST[modObj ? modObj.key : '03'] || 30;
    const ts = Math.round(t);
    let cls, txt;
    if (ts <= sug * 0.6) { cls = 'fast'; txt = '偏快'; }
    else if (ts <= sug * 1.3) { cls = 'ok'; txt = '正常'; }
    else { cls = 'slow'; txt = '偏慢'; }
    paceHtml = `<span class="pace ${cls}">建议 ${sug}s · ${txt}</span>`;
  }
  ans.innerHTML = `正确答案：<b>${q.correct.join('、')}</b>${q.answer && q.answer !== q.correct.join('') ? ` （答案标注：${q.answer}）` : ''}${paceHtml}`;

  const wrap = document.createElement('div');
  if (q.analysis && q.analysis.trim()) {
    const t2 = document.createElement('div'); t2.className = 'analysis-title'; t2.textContent = '官方解析';
    const a = document.createElement('div'); a.className = 'analysis'; a.innerHTML = q.analysis;
    wrap.appendChild(t2); wrap.appendChild(a);
  } else { const note = document.createElement('div'); note.className = 'muted'; note.textContent = '（本题暂无官方解析）'; wrap.appendChild(note); }
  res.innerHTML = ''; res.appendChild(verdict); res.appendChild(ans); res.appendChild(wrap);
}

function updateSidePanel() {
  const s = state.session; if (!s) return;
  $('#side-prog-text').textContent = `第 ${s.index + 1} / ${s.questions.length} 题`;
  $('#side-prog-fill').style.width = ((s.index + 1) / s.questions.length * 100) + '%';
  let done = 0, right = 0, wrong = 0;
  s.questions.forEach((q, i) => { if (s.submitted[i]) { done++; if (s.results[i] === true) right++; else wrong++; } });
  $('#sc-done').textContent = done;
  $('#sc-right').textContent = right;
  $('#sc-wrong').textContent = wrong;
  $('#sc-rate').textContent = done ? Math.round((right / done) * 100) + '%' : '--';
}

function nextQuestion() { const s = state.session; if (!s) return; if (s.index < s.questions.length - 1) { s.index++; renderQuestion(); } }
function prevQuestion() { const s = state.session; if (!s) return; if (s.index > 0) { s.index--; renderQuestion(); } }

// ---------- 结束 / 交卷 ----------
function endSession() {
  const s = state.session; if (!s) { switchView('practice'); return; }
  s.ended = true; stopTimer(); saveDailyMap();
  let done = 0, right = 0, wrong = 0;
  if (s.kind === 'exam') {
    s.questions.forEach((q, i) => {
      if (!s.submitted[i]) { s.submitted[i] = true; s.results[i] = false; }
      done++; if (s.results[i] === true) right++; else wrong++;
      syncWrong(q, s.results[i] === true);
    });
  } else {
    s.questions.forEach((q, i) => { if (s.submitted[i]) { done++; if (s.results[i] === true) right++; else wrong++; } });
  }
  if (!s.noRecord) addRecord({ mode: s.kind, moduleLabel: s.moduleLabel, count: s.questions.length, right, wrong, secs: s.elapsed });
  markCheckin(todayStr());
  // 累计到每日统计（练习时长由计时器逐秒累加，这里只补题数；考试时长需在此补入）
  const td = todayStr();
  const dm = state.dailyMap[td] || (state.dailyMap[td] = { secs: 0, questions: 0 });
  dm.questions += s.questions.length;
  if (s.kind === 'exam') dm.secs += s.elapsed;
  saveDailyMap();
  renderHome();
  if (s.kind === 'exam') showExamReport(s, { done, right, wrong });
  else { state.session = null; switchView('practice'); toast('已结束练习'); }
}

function showExamReport(s, stats) {
  const total = s.questions.length;
  const rate = stats.done ? Math.round((stats.right / stats.done) * 100) : 0;
  const byMod = {};
  s.questions.forEach((q, i) => {
    const m = q.module || '未知'; const b = byMod[m] || (byMod[m] = { right: 0, total: 0 });
    b.total++; if (s.results[i] === true) b.right++;
  });
  let modHtml = '';
  Object.keys(byMod).sort((a, b) => byMod[b].total - byMod[a].total).forEach((m) => {
    const b = byMod[m]; const p = b.total ? Math.round((b.right / b.total) * 100) : 0; const w = Math.max(4, p);
    modHtml += `<div class="row"><div class="nm">${m}</div><div class="track"><i style="width:${w}%"></i></div><div class="pc">${b.right}/${b.total} · ${p}%</div></div>`;
  });
  const head = s.review ? '练习报告' : '模拟考试报告';
  // 免费版锁定「各模块表现」明细（最有价值的分析部分），保留总分与对错数
  const activated = isActivated();
  const modBlock = activated
    ? `<div class="mod-break"><div class="analysis-title">各模块表现</div>${modHtml}</div>`
    : `<div class="mod-break"><div class="analysis-title">各模块表现</div>` +
      `<div class="lic-locked">` +
      `<div class="lic-lock-title">各模块表现明细为专业版功能</div>` +
      `<div class="lic-lock-desc">激活后可查看六大模块的正确率对比，精准定位薄弱模块。</div>` +
      `<button class="primary sm" id="rp-activate">激活解锁</button>` +
      `</div></div></div>`;

  const html =
    `<div class="report-head">${head}</div>` +
    `<div class="report-score">` +
    `<div class="score-card"><div class="l">正确率</div><div class="n ${rate >= 60 ? 'ok' : 'bad'}">${rate}%</div></div>` +
    `<div class="score-card"><div class="l">答对</div><div class="n ok">${stats.right}</div></div>` +
    `<div class="score-card"><div class="l">答错/未答</div><div class="n bad">${total - stats.right}</div></div>` +
    `<div class="score-card"><div class="l">用时</div><div class="n">${fmtTime(s.elapsed)}</div></div>` +
    `</div>` +
    modBlock +
    `<div class="report-actions">` +
    (s.examPreset ? `<button class="primary" id="rp-again">再模拟一次</button>` : `<button class="primary" id="rp-again">再做一组</button>`) +
    `<button class="ghost" id="rp-back">返回</button>` +
    `</div>`;
  $('#session').hidden = true;
  $('#practice-side').hidden = true;
  const r = $('#session-report'); r.hidden = false; r.innerHTML = html;
  $('#rp-back').addEventListener('click', () => { state.session = null; switchView(s.examPreset ? 'exam' : 'practice'); });
  $('#rp-again').addEventListener('click', () => { if (s.examPreset) startExam(s.examPreset.id); else startPractice(null); });
  const actBtn = $('#rp-activate');
  if (actBtn) actBtn.addEventListener('click', () => { state.session = null; switchView('license'); });
}

function endPractice() {
  const s = state.session; if (!s) return;
  if (s.kind === 'exam') { if (!confirm('确定交卷？未作答题目将计为错误。')) return; endSession(); }
  else { if (!confirm('结束本次练习？已作答记录会保留，计时停止。')) return; endSession(); }
}
function backToFilter() {
  if (!state.session) { switchView('practice'); return; }
  if (!confirm('放弃当前练习组并返回？')) return;
  state.session = null; stopTimer(); switchView('practice');
}

// ---------- 错题本 ----------
function addWrong(q) {
  const exists = Object.prototype.hasOwnProperty.call(state.wrong, q.qid);
  const ex = exists ? state.wrong[q.qid] : {};
  const cnt = Object.keys(state.wrong).length;

  // 免费版：错题本条数上限。达到上限时提示激活，激活后不限条数。
  if (!isActivated() && FREE_LIMIT.wrongLimit > 0 && !exists && cnt >= FREE_LIMIT.wrongLimit) {
    showLimitModal('错题本已满 ' + FREE_LIMIT.wrongLimit + ' 条',
      limitNotice('的错题本收录额度（' + FREE_LIMIT.wrongLimit + ' 条）'));
    return;   // 本题不收录，等激活后由用户重新作答
  }

  state.wrong[q.qid] = {
    module: q.module, paper: q.paper, no: q.no, type: q.type,
    stem: truncate(q.stem), correct: q.correct, year: q.year, region: q.region,
    wrongCount: (ex.wrongCount || 0) + 1, firstWrong: ex.firstWrong || Date.now(),
    lastWrong: Date.now(), mastered: ex.mastered || false, note: ex.note || '',
  };
}
function toggleFav() {
  const s = state.session; if (!s) return;
  const q = s.questions[s.index];
  if (state.fav[q.qid]) { delete state.fav[q.qid]; toast('已取消收藏'); }
  else {
    // 免费版：收藏条数上限。达到上限时提示激活，激活后不限条数。
    if (!isActivated() && FREE_LIMIT.favLimit > 0 && Object.keys(state.fav).length >= FREE_LIMIT.favLimit) {
      showLimitModal('收藏已满 ' + FREE_LIMIT.favLimit + ' 条',
        limitNotice('的收藏额度（' + FREE_LIMIT.favLimit + ' 条）'));
      return;
    }
    state.fav[q.qid] = { module: q.module, paper: q.paper, no: q.no, type: q.type, stem: truncate(q.stem), correct: q.correct, year: q.year, region: q.region, note: '', added: Date.now() };
    toast('已收藏本题');
  }
  saveFav();
}
function reviewWrong() {
  const qids = Object.keys(state.wrong);
  if (!qids.length) { toast('错题本为空'); return; }
  toast('加载错题…');
  loadQuestionsByIds(qids).then((qs) => { if (qs.length) startPractice(qs); else toast('未找到对应题目'); });
}
async function reviewSmart() {
  const entries = Object.entries(state.wrong).filter(([id, w]) => !w.mastered);
  if (!entries.length) { toast('没有待复习的错题'); return; }
  entries.sort((a, b) => (b[1].wrongCount - a[1].wrongCount) || (a[1].lastWrong - b[1].lastWrong));
  const ids = entries.slice(0, 30).map(([id]) => id);
  const qs = await loadQuestionsByIds(ids);
  if (!qs.length) { toast('未找到对应题目'); return; }
  toast('智能复习：优先薄弱错题');
  startPractice(qs, { smart: true });
}

async function loadQuestionsByIds(ids) {
  const byKey = {};
  ids.forEach((id) => {
    const store = state.wrong[id] || state.fav[id];
    if (!store) return;
    const key = moduleKeyByName(store.module);
    if (!key) return;
    (byKey[key] = byKey[key] || []).push(id);
  });
  const questions = [];
  try {
    for (const key of Object.keys(byKey)) {
      const arr = await getModule(key);
      byKey[key].forEach((id) => { const q = arr.find((x) => x.qid === id); if (q) questions.push(q); });
    }
  } catch (e) { toast(e.message); }
  return questions;
}

function renderWrongList() {
  const list = $('#wrong-list');
  const mod = $('#wf-module').value;
  const kw = ($('#wf-search').value || '').trim().toLowerCase();
  const showMastered = $('#wf-mastered').checked;
  updateUsageChip('#wrong-count', Object.keys(state.wrong).length, FREE_LIMIT.wrongLimit);
  let items = Object.entries(state.wrong).map(([id, w]) => Object.assign({ id }, w));
  if (mod) items = items.filter((w) => w.module === mod);
  if (kw) items = items.filter((w) => stripTags(w.stem).toLowerCase().includes(kw));
  if (!showMastered) items = items.filter((w) => !w.mastered);
  items.sort((a, b) => (b.lastWrong || 0) - (a.lastWrong || 0));
  if (!items.length) { list.innerHTML = '<div class="panel muted">没有符合条件的错题。</div>'; return; }
  list.innerHTML = '';
  items.forEach((w) => {
    const item = document.createElement('div');
    item.className = 'wrong-item' + (w.mastered ? ' mastered' : '');
    const ans = w.correct ? ('正确答案：' + w.correct.join('、')) : '';
    item.innerHTML =
      `<div class="wi-meta"><span>模块：${w.module}</span><span>题型：${w.type || '—'}</span><span>错 ${w.wrongCount || 1} 次</span></div>` +
      `<div class="wi-stem">${w.stem || w.paper || ''}</div>` +
      (ans ? `<div class="wi-answer">${ans}</div>` : '') +
      (w.note ? `<div class="wi-note">批注：${escapeHtml(w.note)}</div>` : '') +
      `<div class="wi-actions">` +
      `<button class="ghost sm" data-review="${w.id}">复习本题</button>` +
      `<button class="ghost sm" data-master="${w.id}">${w.mastered ? '取消掌握' : '标记掌握'}</button>` +
      `<button class="ghost sm" data-remove="${w.id}">移出</button>` +
      `</div>`;
    list.appendChild(item);
  });
  $$('#wrong-list [data-review]').forEach((b) => b.addEventListener('click', () => reviewOne(b.dataset.review)));
  $$('#wrong-list [data-master]').forEach((b) => b.addEventListener('click', () => toggleMastered(b.dataset.master)));
  $$('#wrong-list [data-remove]').forEach((b) => b.addEventListener('click', () => removeWrong(b.dataset.remove)));
}
function reviewOne(id) { loadQuestionsByIds([id]).then((qs) => { if (qs.length) startPractice(qs); else toast('未找到该题目'); }); }
function removeWrong(id) { if (state.wrong[id]) { delete state.wrong[id]; saveWrong(); renderWrongList(); toast('已移出错题本'); } }
function toggleMastered(id) { if (state.wrong[id]) { state.wrong[id].mastered = !state.wrong[id].mastered; saveWrong(); renderWrongList(); toast(state.wrong[id].mastered ? '已标记掌握' : '已取消掌握'); } }
function clearWrong() {
  if (!Object.keys(state.wrong).length) { toast('错题本已为空'); return; }
  if (!confirm('确定清空错题本？此操作不可撤销。')) return;
  state.wrong = {}; saveWrong(); renderWrongList(); toast('已清空');
}
function exportWrong() {
  const items = Object.entries(state.wrong).map(([id, w]) => Object.assign({ id }, w));
  if (!items.length) { toast('错题本为空'); return; }
  let txt = '行测真题训练系统 · 错题导出\n导出时间：' + new Date().toLocaleString() + '\n共 ' + items.length + ' 题\n\n';
  items.forEach((w, i) => {
    txt += `【${i + 1}】${w.module} · ${w.type || ''}\n题目：${stripTags(w.stem)}\n正确答案：${(w.correct || []).join('、')}\n`;
    if (w.note) txt += `批注：${w.note}\n`;
    txt += '\n';
  });
  downloadText('行测错题本_' + todayStr() + '.txt', txt);
  toast('已导出错题');
}

// ---------- 收藏 ----------
function renderFavList() {
  const list = $('#fav-list');
  const mod = $('#ff-module').value;
  const kw = ($('#ff-search').value || '').trim().toLowerCase();
  updateUsageChip('#fav-count', Object.keys(state.fav).length, FREE_LIMIT.favLimit);
  let items = Object.entries(state.fav).map(([id, w]) => Object.assign({ id }, w));
  if (mod) items = items.filter((w) => w.module === mod);
  if (kw) items = items.filter((w) => stripTags(w.stem).toLowerCase().includes(kw));
  items.sort((a, b) => (b.added || 0) - (a.added || 0));
  if (!items.length) { list.innerHTML = '<div class="panel muted">还没有收藏。做题时点「收藏本题」即可加入。</div>'; return; }
  list.innerHTML = '';
  items.forEach((w) => {
    const item = document.createElement('div');
    item.className = 'wrong-item';
    item.innerHTML =
      `<div class="wi-meta"><span>模块：${w.module}</span><span>题型：${w.type || '—'}</span></div>` +
      `<div class="wi-stem">${w.stem || w.paper || ''}</div>` +
      (w.note ? `<div class="wi-note">批注：${escapeHtml(w.note)}</div>` : '') +
      `<div class="wi-actions">` +
      `<button class="ghost sm" data-review="${w.id}">复习本题</button>` +
      `<button class="ghost sm" data-note="${w.id}">${w.note ? '编辑批注' : '加批注'}</button>` +
      `<button class="ghost sm danger" data-remove="${w.id}">取消收藏</button>` +
      `</div>`;
    list.appendChild(item);
  });
  $$('#fav-list [data-review]').forEach((b) => b.addEventListener('click', () => reviewFavOne(b.dataset.review)));
  $$('#fav-list [data-note]').forEach((b) => b.addEventListener('click', () => editFavNote(b.dataset.note)));
  $$('#fav-list [data-remove]').forEach((b) => b.addEventListener('click', () => removeFav(b.dataset.remove)));
}
function reviewFavOne(id) { loadQuestionsByIds([id]).then((qs) => { if (qs.length) startPractice(qs, { favReview: true }); else toast('未找到该题目'); }); }
function editFavNote(id) {
  const w = state.fav[id]; if (!w) return;
  const v = window.prompt('为本題添加/编辑批注：', w.note || '');
  if (v === null) return;
  w.note = v.trim(); saveFav(); renderFavList(); toast('批注已保存');
}
function removeFav(id) { if (state.fav[id]) { delete state.fav[id]; saveFav(); renderFavList(); toast('已取消收藏'); } }
function reviewFavAll() {
  const ids = Object.keys(state.fav);
  if (!ids.length) { toast('收藏为空'); return; }
  toast('加载收藏…');
  loadQuestionsByIds(ids).then((qs) => { if (qs.length) startPractice(qs, { favReview: true }); else toast('未找到对应题目'); });
}
function clearFav() {
  if (!Object.keys(state.fav).length) { toast('收藏已为空'); return; }
  if (!confirm('确定清空收藏？此操作不可撤销。')) return;
  state.fav = {}; saveFav(); renderFavList(); toast('已清空');
}
function exportFav() {
  const items = Object.entries(state.fav).map(([id, w]) => Object.assign({ id }, w));
  if (!items.length) { toast('收藏为空'); return; }
  let txt = '行测真题训练系统 · 收藏导出\n导出时间：' + new Date().toLocaleString() + '\n共 ' + items.length + ' 题\n\n';
  items.forEach((w, i) => {
    txt += `【${i + 1}】${w.module}\n题目：${stripTags(w.stem)}\n正确答案：${(w.correct || []).join('、')}\n`;
    if (w.note) txt += `批注：${w.note}\n`;
    txt += '\n';
  });
  downloadText('行测收藏_' + todayStr() + '.txt', txt);
  toast('已导出收藏');
}

// ---------- 进度备份 ----------
function exportProgress() {
  const data = { version: 2, exportedAt: Date.now(), wrong: state.wrong, fav: state.fav, stats: state.stats, dailyMap: state.dailyMap, checkin: state.checkin };
  downloadText('行测刷题进度_' + todayStr() + '.json', JSON.stringify(data, null, 2));
  toast('已导出进度备份');
}
function importProgress(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result);
      if (!confirm('导入将覆盖本机当前的错题、收藏、统计与打卡记录，确定继续？')) return;
      state.wrong = data.wrong || {};
      state.fav = data.fav || {};
      state.stats = data.stats || [];
      state.dailyMap = data.dailyMap || {};
      state.checkin = data.checkin || {};
      if (!state.dailyMap[todayStr()]) state.dailyMap[todayStr()] = { secs: 0, questions: 0 };
      saveWrong(); saveFav(); saveStats(); saveDailyMap(); saveCheckin();
      updateBadges(); renderHome(); renderStats();
      toast('进度已导入');
    } catch (e) { toast('文件解析失败'); }
  };
  reader.readAsText(file);
}
function downloadText(name, text) {
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// ---------- 首页 ----------
function renderHome() {
  const streak = computeStreak();
  $('#hc-streak').textContent = streak;
  $('#hc-sub').textContent = state.checkin[todayStr()] ? '今天已打卡，继续保持' : '点击右侧「今日打卡」开启连续记录';
  const bar = $('#hc-bar'); bar.innerHTML = '';
  for (let i = 6; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i);
    const ds = fmtDate(d); const on = !!state.checkin[ds];
    const i2 = document.createElement('i'); i2.className = (on ? (i === 0 ? 'today' : 'on') : ''); i2.title = ds + (on ? ' 已打卡' : '');
    bar.appendChild(i2);
  }
  let totalQ = 0, right = 0, wrong = 0;
  state.stats.forEach((r) => { totalQ += r.count; right += r.right; wrong += r.wrong; });
  const secs = Object.values(state.dailyMap).reduce((a, d) => a + (d.secs || 0), 0);
  $('#snap-q').textContent = totalQ.toLocaleString();
  $('#snap-rate').textContent = (right + wrong) ? Math.round((right / (right + wrong)) * 100) + '%' : '--';
  $('#snap-time').textContent = (secs / 3600).toFixed(1) + 'h';
  $('#snap-wrong').textContent = Object.values(state.wrong).filter((w) => !w.mastered).length;
  // 薄弱模块
  const acc = {};
  state.stats.forEach((r) => {
    if (r.moduleLabel && r.moduleLabel.indexOf('全卷') === -1 && r.moduleLabel.indexOf('复习') === -1 && r.moduleLabel.indexOf('自定义') === -1) {
      const b = acc[r.moduleLabel] || (acc[r.moduleLabel] = { right: 0, wrong: 0 });
      b.right += r.right; b.wrong += r.wrong;
    }
  });
  const arr = Object.keys(acc).map((m) => ({ m, att: acc[m].right + acc[m].wrong, p: (acc[m].right + acc[m].wrong) ? acc[m].right / (acc[m].right + acc[m].wrong) : 1 }))
    .filter((x) => x.att >= 5).sort((a, b) => a.p - b.p);
  const weak = $('#home-weak');
  if (!arr.length) weak.innerHTML = '<div class="weak-empty" style="color:var(--ok)">暂无足够数据，多做几组练习即可看到薄弱模块。</div>';
  else {
    const top = arr.slice(0, 2);
    weak.innerHTML = top.map((x) => `<div class="weak-item">${x.m}：正确率 ${Math.round(x.p * 100)}%（${x.att} 题）</div>`).join('')
      + (arr[0].p < 0.6 ? '<div class="muted small">该模块明显偏弱，建议优先安排专项练习。</div>' : '');
  }
  renderHomeTrend();
  renderHomeRecords();
}

// 首页：近 30 天趋势 + 最近记录
function renderHomeTrend() {
  const trend = $('#home-trend');
  if (!trend) return;
  trend.innerHTML = '';
  const days = [];
  for (let i = 29; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); days.push(d); }
  const maxQ = Math.max(1, ...days.map((d) => (state.dailyMap[fmtDate(d)] || {}).questions || 0));
  days.forEach((d) => {
    const q = (state.dailyMap[fmtDate(d)] || {}).questions || 0;
    const h = Math.max(2, Math.round(q / maxQ * 100));
    const cell = document.createElement('div'); cell.className = 'tbar';
    cell.innerHTML = `<div class="col" style="height:${h}%;background:${q ? 'var(--accent)' : 'var(--line)'}"></div><div class="d">${d.getDate()}</div>`;
    cell.title = fmtDate(d) + ' · ' + q + ' 题';
    trend.appendChild(cell);
  });
}

function renderHomeRecords() {
  const rec = $('#home-records');
  if (!rec) return;
  if (!state.stats.length) { rec.innerHTML = '<div class="muted">还没有练习记录，去「快速开始」练第一组吧。</div>'; return; }
  rec.innerHTML = '';
  state.stats.slice(-6).reverse().forEach((r) => {
    const p = (r.right + r.wrong) ? Math.round((r.right / (r.right + r.wrong)) * 100) : 0;
    const rt = r.ts ? new Date(r.ts) : new Date();
    const item = document.createElement('div'); item.className = 'record-item';
    const tagCls = r.mode === 'exam' ? 'r-tag exam' : 'r-tag';
    item.innerHTML =
      `<span class="${tagCls}">${r.mode === 'exam' ? '模拟' : '练习'}</span>` +
      `<span class="r-main">${r.moduleLabel} · ${r.count} 题</span>` +
      `<span class="r-sub">正确率 ${p}% · ${fmtTime(r.secs)} · ${rt.getMonth() + 1}/${rt.getDate()}</span>`;
    rec.appendChild(item);
  });
}

function dailyQuestion() {
  const mods = state.manifest.modules;
  const m = mods[Math.floor(Math.random() * mods.length)];
  toast('加载每日一题…');
  getModule(m.key).then((arr) => {
    const pool = arr.filter((q) => !q.incomplete);
    const q = pool[Math.floor(Math.random() * pool.length)];
    if (!q) { toast('加载失败'); return; }
    state.session = buildSession([q], { kind: 'practice', review: false, timeLimit: 0, moduleLabel: m.name, noRecord: true });
    beginSession();
  }).catch((e) => toast(e.message));
}

// ---------- 激活 ----------
// 校验全部走主进程 IPC（渲染层无 Node 权限，也无 RSA 验签能力）
// 注意：preload 已通过 contextBridge 暴露 window.xcAPI，
// 这里不能再用 const xcAPI 声明同名全局变量，否则会抛
// "Identifier 'xcAPI' has already been declared" 导致整个脚本中断。
// 改用不同名字引用，避免与 preload 的全局属性冲突。
const xcLicenseAPI = (typeof window !== 'undefined' && window.xcAPI) ? window.xcAPI : null;

// 授权状态缓存：免费版限制的判定依据
state.license = { activated: false, plan: null, universal: false, expire: 0 };

// 免费版限制参数（未激活时生效）
// 免费版限制设计：
// 额度为「终身累计总量」，用尽即止，不按天重置。
// 练习 50 题 + 模考 3 套 —— 足以让用户完整体验核心功能（练习/模考/错题/收藏/统计），
// 又不足以完成一轮系统备考，形成自然的付费转化点。
// 导出/导入进度备份不设限制 —— 那是用户数据的所有权，不该用付费墙卡住。
const FREE_LIMIT = {
  examLimit: 3,         // 模拟考试总套数（0 = 不限）
  questionLimit: 50,    // 练习题量总题数（0 = 不限）
  wrongLimit: 30,       // 错题本最多保留条数
  favLimit: 20,         // 收藏最多保留条数
};

function getExamCountKey() { return 'xc_examcount_total'; }
function getExamCountTotal() {
  try { return parseInt(localStorage.getItem(getExamCountKey()) || '0', 10) || 0; }
  catch (e) { return 0; }
}
function incExamCountTotal() {
  try { localStorage.setItem(getExamCountKey(), String(getExamCountTotal() + 1)); } catch (e) {}
}
function getQuestionCountKey() { return 'xc_qcount_total'; }
function getQuestionCountTotal() {
  try { return parseInt(localStorage.getItem(getQuestionCountKey()) || '0', 10) || 0; }
  catch (e) { return 0; }
}
function incQuestionCountTotal(n) {
  try { localStorage.setItem(getQuestionCountKey(), String(getQuestionCountTotal() + (n || 0))); } catch (e) {}
}

/**
 * 旧版限制按天计数（xc_qcount_日期 / xc_examcount_日期），新版改为终身累计总量。
 * 升级时把历史按日计数汇总进累计值，避免老用户额度凭空回满。
 * 仅在累计 key 不存在时执行一次，迁移后不再重复。
 */
function migrateLimitsToTotal() {
  try {
    if (localStorage.getItem('xc_limits_migrated') === '1') return;
    // 只统计「旧版按日 key」：xc_qcount_ + 8 位日期，排除新版的 _total
    const DATE_SUFFIX = /^\d{4}-\d{2}-\d{2}$/;
    const allKeys = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k) allKeys.push(k);
    }
    const sumDaily = (prefix) => {
      let total = 0;
      allKeys.forEach((k) => {
        if (k.indexOf(prefix) !== 0) return;
        if (!DATE_SUFFIX.test(k.slice(prefix.length))) return;
        total += parseInt(localStorage.getItem(k) || '0', 10) || 0;
      });
      return total;
    };
    const q = Math.max(getQuestionCountTotal(), sumDaily('xc_qcount_'));
    const e = Math.max(getExamCountTotal(), sumDaily('xc_examcount_'));
    localStorage.setItem(getQuestionCountKey(), String(q));
    localStorage.setItem(getExamCountKey(), String(e));
    // 清理旧的按日 key（只删日期格式的，保留 _total）
    allKeys.forEach((k) => {
      if (k.indexOf('xc_qcount_') === 0 && DATE_SUFFIX.test(k.slice('xc_qcount_'.length))) localStorage.removeItem(k);
      else if (k.indexOf('xc_examcount_') === 0 && DATE_SUFFIX.test(k.slice('xc_examcount_'.length))) localStorage.removeItem(k);
    });
    localStorage.setItem('xc_limits_migrated', '1');
  } catch (e) {}
}

function isActivated() { return !!(state.license && state.license.activated); }

/** 未激活时的限制检查：返回限制说明文本，不通过则返回 null 表示放行 */
function checkFreeLimit(kind, count) {
  if (isActivated()) return null;
  if (kind === 'exam') {
    if (FREE_LIMIT.examLimit > 0 && getExamCountTotal() >= FREE_LIMIT.examLimit) {
      return '免费版总共可做 ' + FREE_LIMIT.examLimit + ' 套模拟考试。激活后不限次数，并解锁成绩报告。';
    }
  }
  if (kind === 'practice' && FREE_LIMIT.questionLimit > 0 && count > FREE_LIMIT.questionLimit) {
    return '免费版总共最多练习 ' + FREE_LIMIT.questionLimit + ' 题。激活后不限题量。';
  }
  return null;
}

/** 根据激活状态切换激活页的显示：已激活时隐藏输入区，显示成功态 */
function updateLicenseView() {
  const form = $('#lic-form');
  const done = $('#lic-done');
  const feat = $('#lic-feature');
  const tips = $('#lic-tips');
  const heroDesc = $('#lic-hero-desc');
  const device = $('#lic-device');
  const activated = isActivated();
  if (form) form.hidden = activated;
  if (done) done.hidden = !activated;
  // 已激活后不再需要机器码、解锁说明与使用说明
  if (device) device.hidden = activated;
  if (feat) feat.hidden = activated;
  if (tips) tips.hidden = activated;
  // 价格卡：已激活后隐藏购买引导、显示已拥有标记
  const priceBuy = $('#lic-price-buy');
  const priceOwned = $('#lic-price-owned');
  if (priceBuy) priceBuy.hidden = activated;
  if (priceOwned) priceOwned.hidden = !activated;
  if (heroDesc) {
    heroDesc.textContent = activated
      ? '你已解锁全部功能，感谢支持。'
      : '本软件一机一码。先把下面的机器码发给作者，收到专属授权码后粘贴激活。';
  }
  // 导航栏「激活」旁的红点：已激活则隐藏
  const dot = $('#lic-badge');
  if (dot) dot.hidden = activated;
}

/** 把机器码填到激活页与上限弹窗两处 */
function fillMachine(mc) {
  const text = mc || '未获取到';
  const a = $('#lic-machine');
  if (a) a.textContent = text;
  const b = $('#lic-modal-machine');
  if (b) b.textContent = text;
}

function fallbackCopy(text, done) {
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    if (ok) done(); else toast('复制失败，请手动选中机器码');
  } catch (e) {
    toast('复制失败，请手动选中机器码');
  }
}

/** 复制机器码：优先 Clipboard API，失败时退回 execCommand */
function copyMachine() {
  const el = $('#lic-machine');
  const mc = (el ? el.textContent : '').trim();
  if (!mc || /读取中|未获取|不可用/.test(mc)) { toast('机器码还没读到，请稍等'); return; }
  const done = () => toast('机器码已复制，发给作者即可');
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(mc).then(done).catch(() => fallbackCopy(mc, done));
  } else {
    fallbackCopy(mc, done);
  }
}

async function loadLicenseInfo() {
  const badge = $('#lic-badge');
  const statusEl = $('#lic-status');
  if (!xcLicenseAPI || !xcLicenseAPI.license) {
    // 网页预览模式：无法激活，仅展示说明
    if (statusEl) { statusEl.textContent = '网页版不可用'; statusEl.classList.remove('on'); }
    if (badge) badge.hidden = true;
    fillMachine('仅桌面版可用');
    updateLicenseView();
    return;
  }
  try {
    const info = await xcLicenseAPI.license.info();
    state.license = info;
    fillMachine(info.machineCode);
    if (statusEl) {
      if (info.activated) {
        statusEl.textContent = info.plan === 'life' ? '已激活 · 永久版' : '已激活 · 专业版';
        statusEl.classList.add('on');
      } else {
        statusEl.textContent = '未激活';
        statusEl.classList.remove('on');
      }
    }
    if (badge) {
      badge.hidden = info.activated;
      badge.classList.toggle('on', info.activated);
    }
    const clearBtn = $('#btn-clear-license');
    if (clearBtn) clearBtn.hidden = !info.activated;
    updateFreeLimitHints();
    updateLicenseView();
  } catch (e) {
    if (statusEl) { statusEl.textContent = '检测失败'; statusEl.classList.remove('on'); }
  }
}

/** 更新错题本/收藏的用量徽章：已用/上限，接近上限时标红 */
function updateUsageChip(sel, used, limit) {
  const el = $(sel);
  if (!el) return;
  if (isActivated() || !limit) { el.textContent = ''; el.hidden = true; return; }
  el.hidden = false;
  el.textContent = used + ' / ' + limit;
  el.classList.toggle('near', used >= limit * 0.8);
  el.title = '免费版上限 ' + limit + ' 条，激活后不限';
}

// ---------- 达到上限的激活弹窗 ----------
/**
 * 统一的「已达上限」提示：所有功能触顶时都走这里。
 * 弹窗内可直接粘贴激活码完成激活，激活后所有限制立即解除。
 * @param {string} title 弹窗标题
 * @param {string} desc  说明文字
 */
function showLimitModal(title, desc) {
  const modal = $('#lic-modal');
  if (!modal) { toast(title + '，激活后可用全部功能'); return; }
  $('#lic-modal-title').textContent = title;
  $('#lic-modal-desc').innerHTML = desc;
  $('#lic-modal-input').value = '';
  const msg = $('#lic-modal-msg');
  msg.hidden = true; msg.textContent = ''; msg.className = 'lic-modal-msg';
  modal.hidden = false;
  setTimeout(() => { const i = $('#lic-modal-input'); if (i) i.focus(); }, 60);
}

function hideLimitModal() {
  const modal = $('#lic-modal');
  if (modal) modal.hidden = true;
}

async function modalActivate() {
  const input = $('#lic-modal-input');
  const msg = $('#lic-modal-msg');
  const btn = $('#btn-modal-activate');
  const code = (input.value || '').trim();
  if (!code) {
    msg.textContent = '请先粘贴授权码';
    msg.className = 'lic-modal-msg bad';
    msg.hidden = false;
    return;
  }
  if (!xcLicenseAPI || !xcLicenseAPI.license) {
    msg.textContent = '网页预览模式无法激活，请使用桌面版程序';
    msg.className = 'lic-modal-msg bad';
    msg.hidden = false;
    return;
  }
  btn.disabled = true; btn.textContent = '激活中…';
  try {
    const r = await xcLicenseAPI.license.activate(code);
    if (r.ok) {
      msg.textContent = '激活成功！所有功能已解除限制';
      msg.className = 'lic-modal-msg ok';
      msg.hidden = false;
      await loadLicenseInfo();
      updateFreeLimitHints();
      updateBadges();
      setTimeout(() => {
        hideLimitModal();
        toast('激活成功，全部功能已解锁');
        // 若当前视图有限制提示，重新渲染一次
        if (state.session) updateSidePanel();
        renderWrongList(); renderFavList();
      }, 900);
    } else {
      msg.textContent = r.msg || '激活失败';
      msg.className = 'lic-modal-msg bad';
      msg.hidden = false;
    }
  } catch (e) {
    msg.textContent = '激活出错：' + e.message;
    msg.className = 'lic-modal-msg bad';
    msg.hidden = false;
  }
  btn.disabled = false; btn.textContent = '激活并继续使用';
}

/** 统一的触顶提示文案 */
function limitNotice(featureDesc) {
  return '免费版' + featureDesc + '已用完。' +
    '激活后<strong>所有功能均无限制</strong>（练习、模考、错题本、收藏都不限量）。';
}

/** 根据授权状态刷新界面上的免费版限制提示 */
function updateFreeLimitHints() {
  const examUsed = getExamCountTotal();
  const qUsed = getQuestionCountTotal();
  const wrongCnt = Object.keys(state.wrong).length;
  const favCnt = Object.keys(state.fav).length;
  const tips = [
    { el: '#free-limit-hint', show: true },
    { el: '#free-limit-hint-exam', show: true },
  ];
  const activated = isActivated();

  tips.forEach((t) => {
    const hint = $(t.el);
    if (!hint) return;
    if (activated) { hint.hidden = true; return; }
    hint.hidden = false;
    let text;
    if (t.el === '#free-limit-hint-exam') {
      text = '当前为<b>免费版</b>：模拟考试共 ' + FREE_LIMIT.examLimit +
        ' 套（已用 ' + examUsed + ' 套）。';
    } else {
      text = '当前为<b>免费版</b>：练习共 ' + FREE_LIMIT.questionLimit +
        ' 题（已用 ' + qUsed + ' 题）、模拟考试共 ' + FREE_LIMIT.examLimit +
        ' 套、错题本保留最近 ' + FREE_LIMIT.wrongLimit +
        ' 条（现有 ' + wrongCnt + ' 条）、收藏保留最近 ' + FREE_LIMIT.favLimit +
        ' 条（现有 ' + favCnt + ' 条）。';
    }
    text += '<a href="#" class="lic-activate-link">激活后全部解锁</a>';
    hint.innerHTML = text;
  });

  // 绑定跳转事件（避免重复绑定，先解绑再绑）
  $$('.lic-activate-link').forEach((a) => {
    a.onclick = (e) => { e.preventDefault(); switchView('license'); };
  });
}

async function doActivate() {
  const input = $('#lic-input');
  const msg = $('#lic-msg');
  const btn = $('#btn-activate');
  const code = (input.value || '').trim();
  if (!code) { showLicMsg('请先粘贴授权码', true); return; }
  if (!xcLicenseAPI || !xcLicenseAPI.license) { showLicMsg('网页预览模式无法激活，请使用桌面版程序', true); return; }
  btn.disabled = true; btn.textContent = '激活中…';
  try {
    const r = await xcLicenseAPI.license.activate(code);
    showLicMsg(r.msg || (r.ok ? '激活成功' : '激活失败'), !r.ok);
    if (r.ok) {
      input.value = '';
      await loadLicenseInfo();
      toast('激活成功，全部功能已解锁');
    }
  } catch (e) {
    showLicMsg('激活出错：' + e.message, true);
  }
  btn.disabled = false; btn.textContent = '立即激活';
}

function showLicMsg(text, bad) {
  const msg = $('#lic-msg');
  if (!msg) return;
  msg.textContent = text;
  msg.hidden = false;
  msg.classList.toggle('bad', !!bad);
}

function initLicense() {
  const btn = $('#btn-activate');
  if (btn) btn.addEventListener('click', doActivate);

  // 机器码复制（激活页 + 上限弹窗）
  const copyBtn = $('#btn-copy-machine');
  if (copyBtn) copyBtn.addEventListener('click', copyMachine);
  const copyBtn2 = $('#btn-modal-copy');
  if (copyBtn2) copyBtn2.addEventListener('click', copyMachine);

  // 上限弹窗
  const mAct = $('#btn-modal-activate');
  if (mAct) mAct.addEventListener('click', modalActivate);
  const mLater = $('#btn-modal-later');
  if (mLater) mLater.addEventListener('click', hideLimitModal);
  const mMask = document.querySelector('#lic-modal .lic-modal-mask');
  if (mMask) mMask.addEventListener('click', hideLimitModal);
  const mInput = $('#lic-modal-input');
  if (mInput) mInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); modalActivate(); }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const m = $('#lic-modal');
      if (m && !m.hidden) hideLimitModal();
    }
  });
  const doClear = async () => {
    if (!xcLicenseAPI || !xcLicenseAPI.license) return;
    await xcLicenseAPI.license.deactivate();
    await loadLicenseInfo();
    updateLicenseView();
    toast('已清除本机授权');
  };
  const clearBtn = $('#btn-clear-license');
  if (clearBtn) clearBtn.addEventListener('click', doClear);
  const clearBtn2 = $('#btn-clear-license-2');
  if (clearBtn2) clearBtn2.addEventListener('click', doClear);
  const input = $('#lic-input');
  if (input) input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); doActivate(); }
  });
  loadLicenseInfo();
}

// ---------- 学习统计 ----------
function renderStats() {
  let totalQ = 0, right = 0, wrong = 0, secs = 0;
  state.stats.forEach((r) => { totalQ += r.count; right += r.right; wrong += r.wrong; secs += r.secs; });
  const rate = (right + wrong) ? Math.round((right / (right + wrong)) * 100) : 0;
  const streak = computeStreak();
  $('#stats-dash').innerHTML =
    metricCard('累计练习', totalQ.toLocaleString() + '<span class="muted" style="font-size:13px"> 题</span>') +
    metricCard('总正确率', rate + '%', rate >= 60 ? 'ok' : '') +
    metricCard('累计时长', (secs / 3600).toFixed(1) + '<span class="muted" style="font-size:13px"> h</span>') +
    metricCard('连续打卡', streak + '<span class="muted" style="font-size:13px"> 天</span>', 'ok');

  const acc = {};
  state.stats.forEach((r) => {
    if (r.moduleLabel && r.moduleLabel.indexOf('全卷') === -1 && r.moduleLabel.indexOf('复习') === -1 && r.moduleLabel.indexOf('自定义') === -1) {
      const b = acc[r.moduleLabel] || (acc[r.moduleLabel] = { right: 0, wrong: 0 });
      b.right += r.right; b.wrong += r.wrong;
    }
  });
  const cont = $('#stats-mod');
  if (!Object.keys(acc).length) cont.innerHTML = '<div class="muted">还没有单模块练习记录。</div>';
  else {
    cont.innerHTML = '';
    Object.keys(acc).sort((a, b) => (acc[b].right + acc[b].wrong) - (acc[a].right + acc[a].wrong)).forEach((m) => {
      const b = acc[m]; const att = b.right + b.wrong; const p = att ? Math.round((b.right / att) * 100) : 0;
      const weak = p < 60;
      const row = document.createElement('div'); row.className = 'mod-row';
      const w = Math.max(4, p);
      row.innerHTML = `<div class="mod-head"><span style="color:${weak ? 'var(--bad)' : 'var(--ink)'}">${m}</span><span class="muted">${att} 题 · ${p}%</span></div><div class="mod-bar"><i style="width:${w}%;background:${weak ? 'var(--bad)' : 'var(--accent)'}"></i></div>`;
      cont.appendChild(row);
    });
  }

  const trend = $('#stats-trend'); trend.innerHTML = '';
  const days = [];
  for (let i = 29; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); days.push(d); }
  const maxQ = Math.max(1, ...days.map((d) => (state.dailyMap[fmtDate(d)] || {}).questions || 0));
  days.forEach((d) => {
    const q = (state.dailyMap[fmtDate(d)] || {}).questions || 0;
    const h = Math.max(2, Math.round(q / maxQ * 100));
    const cell = document.createElement('div'); cell.className = 'tbar';
    cell.innerHTML = `<div class="col" style="height:${h}%;background:${q ? 'var(--accent)' : 'var(--line)'}"></div><div class="d">${d.getDate()}</div>`;
    cell.title = fmtDate(d) + ' · ' + q + ' 题';
    trend.appendChild(cell);
  });

  const rec = $('#stats-records');
  if (!state.stats.length) rec.innerHTML = '<div class="muted">还没有练习记录。</div>';
  else {
    rec.innerHTML = '';
    state.stats.slice(-25).reverse().forEach((r) => {
      const p = (r.right + r.wrong) ? Math.round((r.right / (r.right + r.wrong)) * 100) : 0;
      const rt = r.ts ? new Date(r.ts) : new Date();
      const item = document.createElement('div'); item.className = 'record-item';
      const tagCls = r.mode === 'exam' ? 'r-tag exam' : 'r-tag';
      item.innerHTML =
        `<span class="${tagCls}">${r.mode === 'exam' ? '模拟' : '练习'}</span>` +
        `<span class="r-main">${r.moduleLabel} · ${r.count} 题</span>` +
        `<span class="r-sub">正确率 ${p}% · ${fmtTime(r.secs)} · ${rt.getMonth() + 1}/${rt.getDate()} ${pad(rt.getHours())}:${pad(rt.getMinutes())}</span>`;
      rec.appendChild(item);
    });
  }
}
function metricCard(label, num, cls) { return `<div class="metric"><div class="metric-label">${label}</div><div class="metric-num ${cls || ''}">${num}</div></div>`; }

// ---------- 题库概览 ----------
/** 渲染「关于」页：版本号与运行环境信息 */
async function renderAbout() {
  const verEl = $('#about-version');
  const envEl = $('#about-env');
  if (!xcLicenseAPI || !xcLicenseAPI.app) {
    if (verEl) verEl.textContent = '版本 —';
    if (envEl) envEl.textContent = '网页预览模式';
    return;
  }
  try {
    const info = await xcLicenseAPI.app.info();
    if (verEl) verEl.textContent = '版本 ' + APP_VERSION;
    if (envEl) {
      envEl.textContent = 'Electron ' + (info.electron || '?')
        + ' · Chromium ' + (info.chrome || '?')
        + ' · ' + (info.platform || '');
    }
  } catch (e) {
    if (verEl) verEl.textContent = '版本 ' + APP_VERSION;
    if (envEl) envEl.textContent = '';
  }
  // 绑定「检查更新」按钮（只绑一次）
  if (!window.__updateBtnBound) {
    window.__updateBtnBound = true;
    const ub = $('#btn-check-update');
    if (ub) ub.addEventListener('click', () => checkUpdate(false));
  }
  // 绑定「创建桌面快捷方式」按钮（只绑一次）
  if (!window.__shortcutBtnBound) {
    window.__shortcutBtnBound = true;
    const sb = $('#btn-desktop-shortcut');
    if (sb) sb.addEventListener('click', async () => {
      if (sb.disabled) return;
      sb.disabled = true;
      const old = sb.textContent;
      sb.textContent = '创建中…';
      try {
        const r = await xcLicenseAPI.app.createDesktopShortcut();
        toast(r && r.ok ? '已在桌面创建快捷方式' : ('创建失败：' + ((r && r.error) || '未知错误')));
      } catch (e) { toast('创建失败：' + (e && e.message ? e.message : e)); }
      finally { sb.disabled = false; sb.textContent = old; }
    });
  }
  // 启动后静默检查一次
  if (!window.__updateChecked) { window.__updateChecked = true; checkUpdate(true); }
}

/* ---------------- 检查更新（jsDelivr 托管的版本描述文件，国内稳定可达） ---------------- */
const UPDATE_OWNER = 'benchao888';     // GitHub 用户名（用于拼接 jsDelivr / raw 地址）
const UPDATE_REPO = 'xingce';          // 仓库名
const APP_VERSION = '1.3.5';           // 当前版本号，发版时务必同步修改

// 版本描述文件 update.json 的多个镜像地址（按可达性排序，国内优先 jsDelivr）。
// 该文件需提交到仓库 git 树（不是 release 附件），由 jsDelivr 等 CDN 直接分发，
// 从而避免依赖 api.github.com（国内常不稳定）与已大面积失效的 ghproxy 代理。
const UPDATE_JSON_URLS = [
  'https://cdn.jsdelivr.net/gh/' + UPDATE_OWNER + '/' + UPDATE_REPO + '@main/update.json',
  'https://fastly.jsdelivr.net/gh/' + UPDATE_OWNER + '/' + UPDATE_REPO + '@main/update.json',
  'https://gcore.jsdelivr.net/gh/' + UPDATE_OWNER + '/' + UPDATE_REPO + '@main/update.json',
  'https://ghproxy.net/https://raw.githubusercontent.com/' + UPDATE_OWNER + '/' + UPDATE_REPO + '/main/update.json',
  'https://raw.githubusercontent.com/' + UPDATE_OWNER + '/' + UPDATE_REPO + '/main/update.json',
];

function escHtml(s) {
  return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
function compareVer(a, b) {
  const pa = String(a).split('.').map(x => parseInt(x, 10) || 0);
  const pb = String(b).split('.').map(x => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}
// 带超时的 fetch：避免国内网络拉 GitHub 时长时间挂起（表现为「点击没反应」）
function fetchWithTimeout(url, ms) {
  const ctrl = new AbortController();
  const tid = setTimeout(() => ctrl.abort(), ms);
  return fetch(url, { cache: 'no-store', signal: ctrl.signal }).finally(() => clearTimeout(tid));
}

async function checkUpdate(silent) {
  const local = APP_VERSION;
  const btn = document.getElementById('btn-check-update');
  if (btn && !silent) { btn.disabled = true; btn.textContent = '检查中…'; }
  const restore = () => { if (btn && !silent) { btn.disabled = false; btn.textContent = '检查更新'; } };
  let lastErr = '未知错误';
  for (const u of UPDATE_JSON_URLS) {
    try {
      const r = await fetchWithTimeout(u, 8000);
      if (!r.ok) { lastErr = 'HTTP ' + r.status; continue; }
      const d = await r.json();
      const latest = String(d.version || '').replace(/^v/i, '');
      if (!latest) { lastErr = '版本信息为空'; continue; }
      // 用成功获取到 update.json 的「同域名」来下载补丁，保证下载源同样可达
      // 兼容两种字段名：patchCdn（现行）/ patch（个别旧缓存节点），避免 CDN 边缘缓存不一致导致取空
      const cdnUrl = d.patchCdn || d.patch || '';
      const rawUrl = d.patchRaw || d.patch || '';
      let patchUrl = cdnUrl;
      if (u.indexOf('jsdelivr.net') >= 0) {
        const host = (u.match(/^https:\/\/[^/]+/) || [''])[0];
        patchUrl = cdnUrl.replace(/^https:\/\/[^/]+/, host);
      } else if (u.indexOf('ghproxy.net') >= 0) {
        patchUrl = 'https://ghproxy.net/' + rawUrl.replace(/^https?:\/\//, '');
      } else {
        patchUrl = rawUrl;
      }
      if (compareVer(latest, local) > 0) {
        restore();
        showUpdateModal('v' + latest, d.notes || '', patchUrl, d.full || '');
      } else {
        restore();
        if (!silent) infoModal('已是最新', '当前已是最新版本 v' + local);
      }
      return;
    } catch (e) {
      lastErr = (e && e.name === 'AbortError') ? '连接超时' : '网络错误';
    }
  }
  restore();
  if (!silent) infoModal('检查失败', '暂时无法连接更新服务器（' + lastErr + '）。可前往作者主页手动下载最新版本。');
}
function showUpdateModal(tag, body, patchUrl, fullUrl) {
  const mask = document.createElement('div');
  mask.className = 'upd-mask';
  const hasAuto = !!patchUrl;
  const hasManual = !!fullUrl;
  const html = '<div class="upd-modal">' +
    '<div class="upd-title">有新版本 ' + escHtml(tag) + '</div>' +
    '<div class="upd-desc">建议更新到最新版本，获得更好的体验与功能修复。</div>' +
    (body ? '<div class="upd-body">' + escHtml(body).replace(/\n/g, '<br>') + '</div>' : '') +
    '<div class="upd-btns">' +
    (hasAuto ? '<button class="upd-btn primary" data-act="auto">一键更新（自动）</button>' : '') +
    (hasManual ? '<button class="upd-btn" data-act="manual">手动下载完整包</button>' : '') +
    '<button class="upd-btn" data-act="later">稍后再说</button>' +
    '</div></div>';
  mask.innerHTML = html;
  document.body.appendChild(mask);
  mask.addEventListener('click', (e) => {
    const b = e.target.closest('.upd-btn');
    if (!b && e.target !== mask) return;
    const act = b ? b.getAttribute('data-act') : 'later';
    if (act === 'auto' && patchUrl) {
      mask.onclick = null;                 // 进入更新流程后禁止点击遮罩关闭
      startAutoUpdate(mask, patchUrl, fullUrl);
      return;
    }
    mask.remove();
    if (act === 'manual' && fullUrl) {
      if (navigator.clipboard) navigator.clipboard.writeText(fullUrl).catch(() => {});
      window.open(fullUrl, '_blank');
    }
  });
}

// 一键自动更新：主进程下载补丁 → 覆盖 resources/app → 重启
function startAutoUpdate(mask, patchUrl, fullUrl) {
  const modal = mask.querySelector('.upd-modal');
  modal.innerHTML = '<div class="upd-title">正在更新</div>' +
    '<div class="upd-stage" id="upd-stage">准备中…</div>' +
    '<div class="upd-bar"><div class="upd-bar-fill" id="upd-bar-fill"></div></div>';
  const stageEl = modal.querySelector('#upd-stage');
  const barEl = modal.querySelector('#upd-bar-fill');
  let finished = false;
  const onProg = (p) => {
    if (finished) return;
    if (stageEl && p.msg) stageEl.textContent = p.msg;
    if (barEl && typeof p.pct === 'number') barEl.style.width = Math.max(0, Math.min(100, p.pct)) + '%';
    if (p.stage === 'done') { finished = true; stageEl.textContent = '更新完成，程序即将重启…'; }
    if (p.stage === 'error') {
      if (modal.querySelector('.upd-btns')) return; // 避免重复追加按钮
      finished = true;
      stageEl.textContent = p.msg || '更新失败';
      const btns = document.createElement('div');
      btns.className = 'upd-btns';
      btns.innerHTML = '<button class="upd-btn primary" data-act="pick">选择补丁文件安装</button>' +
        (fullUrl ? '<button class="upd-btn" data-act="manual2">浏览器下载完整包</button>' : '') +
        '<button class="upd-btn" data-act="close">关闭</button>';
      modal.appendChild(btns);
      // 隐藏文件选择器：用户用浏览器下好补丁后，直接选本地 zip 安装（不依赖软件联网）
      const fileInput = document.createElement('input');
      fileInput.type = 'file'; fileInput.accept = '.zip'; fileInput.style.display = 'none';
      modal.appendChild(fileInput);
      btns.addEventListener('click', (e2) => {
        const b2 = e2.target.closest('.upd-btn'); if (!b2) return;
        const a2 = b2.getAttribute('data-act');
        if (a2 === 'pick') { fileInput.click(); return; }
        if (a2 === 'manual2') { if (fullUrl) { if (navigator.clipboard) navigator.clipboard.writeText(fullUrl).catch(() => {}); window.open(fullUrl, '_blank'); } return; }
        mask.remove();
      });
      fileInput.addEventListener('change', () => {
        const f = fileInput.files && fileInput.files[0];
        if (!f) return;
        const old = modal.querySelector('.upd-btns'); if (old) old.remove();
        finished = false;
        stageEl.textContent = '正在读取补丁文件…';
        if (barEl) barEl.style.width = '0%';
        f.arrayBuffer().then((buf) => xcLicenseAPI.app.applyPatchBuffer(buf)).catch((err) => {
          finished = true;
          stageEl.textContent = '安装失败：' + (err && err.message ? err.message : err);
        });
      });
    }
  };
  if (xcLicenseAPI && xcLicenseAPI.app && xcLicenseAPI.app.onPatchProgress) xcLicenseAPI.app.onPatchProgress(onProg);
  doAutoUpdate(patchUrl, onProg).catch((e) => {
    if (finished) return;
    finished = true;
    if (stageEl) stageEl.textContent = '更新失败：' + (e && e.message ? e.message : e);
  });
}

// 在前端（Chromium 渲染进程）下载补丁：渲染进程能走系统代理/VPN，
// 而 Node 主进程直连常被墙导致超时。下完后把字节交给主进程解压覆盖。
async function doAutoUpdate(patchUrl, onProg) {
  const candidates = (function () {
    if (patchUrl.indexOf('jsdelivr.net') >= 0) {
      const base = patchUrl.replace(/^https?:\/\/[^/]+/, '');
      return ['https://cdn.jsdelivr.net' + base, 'https://fastly.jsdelivr.net' + base, 'https://gcore.jsdelivr.net' + base];
    }
    const noProto = patchUrl.replace(/^https?:\/\//, '');
    return [patchUrl, 'https://ghproxy.net/' + noProto, 'https://kgithub.com/' + noProto];
  })();
  for (const u of candidates) {
    try {
      const r = await fetchWithTimeout(u, 25000);
      if (!r.ok) continue;
      const total = parseInt(r.headers.get('content-length') || '0', 10);
      const reader = r.body.getReader();
      const chunks = []; let received = 0;
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(value); received += value.length;
        if (total) {
          const p = Math.floor((received / total) * 100);
          onProg({ stage: 'download', pct: p, msg: '下载中 ' + (received / 1048576).toFixed(1) + '/' + (total / 1048576).toFixed(1) + ' MB' });
        }
      }
      const blob = new Uint8Array(received); let off = 0;
      for (const c of chunks) { blob.set(c, off); off += c.length; }
      onProg({ stage: 'download', pct: 100, msg: '下载完成，正在应用…' });
      await xcLicenseAPI.app.applyPatchBuffer(blob.buffer);
      return;
    } catch (e) { /* 尝试下一个源 */ }
  }
  // 前端所有源均失败：不强求主进程（Node）直连下载（常被墙会卡 60 秒），
  // 直接引导用户用「选择补丁文件安装」按钮，以浏览器下载后手动安装。
  throw new Error('自动下载失败：更新服务器在当前网络不可达。请点「选择补丁文件安装」，用浏览器下载补丁后手动安装。');
}
function infoModal(title, msg) {
  const mask = document.createElement('div');
  mask.className = 'upd-mask';
  mask.innerHTML = '<div class="upd-modal"><div class="upd-title">' + escHtml(title) +
    '</div><div class="upd-desc">' + escHtml(msg) + '</div>' +
    '<div class="upd-btns"><button class="upd-btn primary" data-act="ok">知道了</button></div></div>';
  document.body.appendChild(mask);
  mask.addEventListener('click', () => mask.remove());
}

function renderOverview() {
  const m = state.manifest;
  const total = m.total;
  const allYears = [].concat(...m.modules.map((x) => x.years));
  const yMin = Math.min(...allYears), yMax = Math.max(...allYears);
  const regionTotals = {};
  m.modules.forEach((mod) => Object.entries(mod.regionCounts || {}).forEach(([r, c]) => { regionTotals[r] = (regionTotals[r] || 0) + c; }));
  const covered = [...PROVINCE_SET].filter((n) => regionTotals[n]).length;

  const dash = $('#dashboard');
  dash.innerHTML =
    metricCard('真题总数', total.toLocaleString()) +
    metricCard('试卷套数', PAPERS) +
    metricCard('年份跨度', yMin + '–' + yMax) +
    metricHTML('省份覆盖', covered + '<span class="muted" style="font-size:14px"> / 34</span>', 'ok');

  const maxC = Math.max(...m.modules.map((x) => x.count));
  const bars = $('#mod-bars'); bars.innerHTML = '';
  m.modules.slice().sort((a, b) => b.count - a.count).forEach((mod) => {
    const pct = Math.max(4, Math.round(mod.count / maxC * 100));
    const row = document.createElement('div'); row.className = 'mod-row';
    row.innerHTML = `<div class="mod-head"><span>${mod.name}</span><span class="muted">${mod.count.toLocaleString()}</span></div><div class="mod-bar"><i style="width:${pct}%"></i></div>`;
    bars.appendChild(row);
  });

  const mapEl = $('#ov-region-map'); mapEl.innerHTML = '';
  [...PROVINCE_SET].sort((a, b) => a.localeCompare(b, 'zh-Hans-CN')).forEach((name) => {
    const c = regionTotals[name] || 0;
    const chip = document.createElement('div'); chip.className = 'region-chip ' + (c ? 'covered' : 'missing');
    chip.title = c ? `${name}：共 ${c} 题` : `${name}：未收录`;
    chip.innerHTML = `<span class="rn">${name}</span><span class="rc">${c ? c + ' 题' : '未收录'}</span>`;
    mapEl.appendChild(chip);
  });
  $('#ov-region-note').textContent = `已收录 ${covered}/34 个省级行政区真题（大陆可参加公考的省级行政区均已覆盖；港、澳、台因考试体系不同未收录）。`;

  const spEl = $('#ov-special'); spEl.innerHTML = '';
  SPECIAL_EXAMS.forEach((name) => {
    const c = regionTotals[name] || 0;
    const chip = document.createElement('div'); chip.className = 'region-chip ' + (c ? 'covered' : 'missing');
    chip.title = c ? `${name}：共 ${c} 题` : `${name}：未收录`;
    chip.innerHTML = `<span class="rn">${name}</span><span class="rc">${c ? c + ' 题' : '无'}</span>`;
    spEl.appendChild(chip);
  });
}
function metricHTML(label, num, cls) { return `<div class="metric"><div class="metric-label">${label}</div><div class="metric-num ${cls || ''}">${num}</div></div>`; }

// ---------- 模拟考试预设 ----------
function renderExamPresets() {
  const box = $('#exam-presets'); if (!box || box.dataset.done) return;
  box.dataset.done = '1';
  box.innerHTML = '';
  EXAM_PRESETS.forEach((p) => {
    const total = Object.values(p.alloc).reduce((a, b) => a + b, 0);
    const card = document.createElement('div');
    card.className = 'exam-preset' + (p.id === state.selectedPreset ? ' selected' : '');
    card.dataset.id = p.id;
    card.innerHTML = `<div class="ep-name">${p.name}</div><div class="ep-meta">${total} 题 · ${p.minutes} 分钟</div>` +
      `<div class="ep-alloc">` + Object.keys(p.alloc).map((k) => { const mm = state.manifest.modules.find((x) => x.key === k); return `<span>${mm ? mm.name : k} ${p.alloc[k]}</span>`; }).join('') + `</div>`;
    card.addEventListener('click', () => { state.selectedPreset = p.id; $$('#exam-presets .exam-preset').forEach((c) => c.classList.toggle('selected', c.dataset.id === p.id)); });
    box.appendChild(card);
  });
}

// ---------- 键盘快捷键 ----------
function onKey(e) {
  const ae = document.activeElement;
  if (ae && (ae.tagName === 'INPUT' || ae.tagName === 'SELECT' || ae.tagName === 'TEXTAREA')) return;
  const v = $('#view-session');
  if (!v || !v.classList.contains('active')) return;
  const s = state.session; const k = e.key;
  if (k === 'Escape') { if (s && !s.ended) { e.preventDefault(); endPractice(); } return; }
  if (!s || s.ended) return;
  if (['a', 'b', 'c', 'd', 'A', 'B', 'C', 'D'].includes(k)) { if (s.submitted[s.index]) return; toggleOption(k.toUpperCase()); e.preventDefault(); return; }
  if (k >= '1' && k <= '9') { if (s.submitted[s.index]) return; const idx = parseInt(k, 10) - 1; const q = s.questions[s.index]; if (q.options[idx]) { toggleOption(q.options[idx].key); e.preventDefault(); } return; }
  if (k === 'Enter' || k === ' ') { if (!s.submitted[s.index]) submitAnswer(); else if (s.index < s.questions.length - 1) nextQuestion(); e.preventDefault(); return; }
  if (k === 'ArrowLeft') { prevQuestion(); e.preventDefault(); return; }
  if (k === 'ArrowRight') { nextQuestion(); e.preventDefault(); return; }
}

// ---------- 事件绑定 ----------
function bind() {
  $$('.navbtn').forEach((b) => b.addEventListener('click', () => switchView(b.dataset.view)));
  $$('.quick-btn').forEach((b) => b.addEventListener('click', () => switchView(b.dataset.go)));

  $('#btn-start').addEventListener('click', () => startPractice());
  $('#btn-review-wrong').addEventListener('click', reviewWrong);
  $('#f-pmode-exam').addEventListener('change', () => { $('#lbl-tlimit').hidden = !$('#f-pmode-exam').checked; });
  $('#btn-submit').addEventListener('click', submitAnswer);
  $('#btn-next').addEventListener('click', nextQuestion);
  $('#btn-prev').addEventListener('click', prevQuestion);
  $('#btn-mark').addEventListener('click', toggleFav);
  $('#btn-end-session').addEventListener('click', endPractice);
  $('#btn-back-filter').addEventListener('click', backToFilter);

  $('#btn-start-exam').addEventListener('click', () => startExam(state.selectedPreset));

  $('#btn-checkin').addEventListener('click', () => { markCheckin(todayStr()); renderHome(); toast('已打卡，连续 ' + computeStreak() + ' 天'); });
  $('#btn-daily').addEventListener('click', dailyQuestion);

  $('#btn-wrong-smart').addEventListener('click', reviewSmart);
  $('#btn-wrong-review').addEventListener('click', reviewWrong);
  $('#btn-wrong-export').addEventListener('click', exportWrong);
  $('#btn-wrong-clear').addEventListener('click', clearWrong);
  $('#wf-module').addEventListener('change', renderWrongList);
  $('#wf-search').addEventListener('input', renderWrongList);
  $('#wf-mastered').addEventListener('change', renderWrongList);

  $('#btn-fav-review').addEventListener('click', reviewFavAll);
  $('#btn-fav-export').addEventListener('click', exportFav);
  $('#btn-fav-clear').addEventListener('click', clearFav);
  $('#ff-module').addEventListener('change', renderFavList);
  $('#ff-search').addEventListener('input', renderFavList);

  $('#btn-export-progress').addEventListener('click', exportProgress);
  $('#btn-import-progress').addEventListener('click', () => $('#import-file').click());
  $('#import-file').addEventListener('change', (e) => { if (e.target.files[0]) importProgress(e.target.files[0]); });

  document.addEventListener('keydown', onKey);
}

// ---------- 启动 ----------
(async function init() {
  bind();
  loadWrong(); loadFav(); loadStats(); loadDailyMap(); loadCheckin(); loadSettings();
  migrateLimitsToTotal();
  updateBadges();
  $('#meta-total').textContent = '离线可用';

  if (location.protocol === 'file:') {
    const box = $('#empty-hint');
    if (box) {
      box.innerHTML =
        '<div style="max-width:580px;margin:40px auto;padding:28px 32px;border:1px solid #f0c2c2;background:#fff5f5;border-radius:12px;line-height:1.9;color:#a33;font-size:15px;">' +
        '<b style="font-size:17px;">启动方式不对</b><br><br>您正直接打开网页文件，浏览器会因安全限制无法读取题库数据。<br><br>' +
        '请关闭此窗口，回到程序所在文件夹，<b>双击「XingCeZhenTi.exe」</b> 启动程序。<br>' +
        '（不要进入 resources 文件夹，也不要直接打开 index.html。）' +
        '</div>';
    }
    return;
  }

  try {
    const res = await fetch('data/manifest.json');
    if (!res.ok) throw new Error('HTTP ' + res.status);
    state.manifest = await res.json();
    $('#meta-total').textContent = '离线 · ' + state.manifest.total.toLocaleString() + ' 题';
    initFilters();
    renderHome();
    initLicense();
  } catch (e) {
    const box = $('#empty-hint');
    if (box) box.innerHTML = '<div style="max-width:560px;margin:40px auto;padding:24px 28px;border:1px solid #f0c2c2;background:#fff5f5;border-radius:12px;color:#a33;line-height:1.8;">无法加载题库数据（data/manifest.json）。<br>请确认程序文件夹完整、未被移动或删减。</div>';
    console.error(e);
  }
})();
